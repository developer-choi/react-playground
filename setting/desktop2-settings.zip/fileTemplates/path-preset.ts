#set($PATH_NAME = $NAME.replace('-path', ''))
#set($UPPER_CASE = $PATH_NAME.toUpperCase())

const upperPath = '/${PATH_NAME}';

const ${UPPER_CASE}_PATH = {
  some: upperPath + '/some'
};

export default ${UPPER_CASE}_PATH;
