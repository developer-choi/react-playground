import React from 'react';
import Head from 'next/head';

export default function Page() {

  return (
    <>
      <Head>
        <title>${NAME}</title>
      </Head>
      <div>
        ${NAME} Page
      </div>
    </>
  );
}
