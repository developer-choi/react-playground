// GET /board/list
export interface BoardListResponse extends PagingResponse {
  list: Board[];
}

// GET /board/another
export interface BoardAnothertResponse {
  another: BoardAnother;
}

/********************************************************************
 *
 ********************************************************************/

export interface Board {
  pk: number;
  title: string;
  content: string;
  timestamp: number;
}

export interface BoardAnother {
  someProperty: string;
}
