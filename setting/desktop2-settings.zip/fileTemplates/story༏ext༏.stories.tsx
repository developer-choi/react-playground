import type {Story} from '@storybook/react';

export default {
  component: $NAME,
  title: 'TEMP/$NAME'
};

const Template: Story<${NAME}Prop> = args => (
    <$NAME {...args}/>
);

export const Default = Template.bind({});
Default.args = {
    
};
