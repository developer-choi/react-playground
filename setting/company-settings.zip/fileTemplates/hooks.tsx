import React from 'react';

interface ${NAME}Props {

}

const ${NAME} = ({}: ${NAME}Props) => {
  return (
      <div></div>
  );
};

export default ${NAME};
