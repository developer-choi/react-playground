import type {NextApiRequest, NextApiResponse} from 'next';

export default function $NAME(req: NextApiRequest, res: NextApiResponse) {
  res.send('hello world');
}
