import React from 'react';

const Page = () => {
  return (
    <div id="layout_wrap">
      <div id="layout_content" className="min-h-[80vh] lg:min-h-0 lg:pb-[10px]">
        $NAME 페이지
      </div>
    </div>
  );
}

export default Page;
