import React from 'react';

const Page = () => {

  return (
      <div>
        ${NAME} Page
      </div>
  );
};

export default Page;
