import React, {ComponentProps} from 'react';

export default function ${NAME}({...rest}: ComponentProps<'svg'>) {
  
  return (
      <svg {...rest}>
      </svg>
  );
}
