import React, {
  useEffect,
  useState,
  useCallback,
  ComponentType,
  ComponentProps,
  ReactNode,
  useRef,
  createContext,
  memo,
  useContext,
  useMemo,
  forwardRef,
  Ref,
  useImperativeHandle,
  ChangeEvent,
  ChangeEventHandler,
  MouseEvent,
  MouseEventHandler,
  FormEvent,
  ReactElement,
  SVGProps
} from 'react';
import type {
  NextApiRequest,
  NextApiResponse,
  PageConfig,
  GetServerSideProps,
  GetServerSidePropsContext,
  GetServerSidePropsResult,
  GetStaticProps,
  GetStaticPaths,
  GetStaticPathsContext,
  GetStaticPathsResult,
  GetStaticPropsContext,
  GetStaticPropsResult,
  NextApiHandler,
  NextPage,
  Redirect
} from 'next';
import Link from 'next/link';
import {useRouter} from 'next/router';
import Head from 'next/head';
import {createSlice, PayloadAction, ThunkAction} from '@reduxjs/toolkit';
import {createApi, fetchBaseQuery} from '@reduxjs/toolkit/dist/query/react';
import {useAppDispatch, useAppSelector} from '@store/hooks';
import {usePrevious} from '@util/custom-hooks/usePrevious';
import type {AppDispatch, RootState} from '@store/store';
import {COLORS} from '@util/style/theme';
import {absoluteAllZero} from '@util/style/css';
import styled, {css, ThemeProvider} from 'styled-components';
import axios, {AxiosError, AxiosInstance, AxiosRequestConfig, AxiosResponse} from 'axios';
import {toast} from 'react-toastify';
import {useQuery, useMutation} from '@tanstack/react-query';
import {useForm, RegisterOptions, SubmitHandler, SubmitErrorHandler, FieldErrors, FieldError, FieldValue} from 'react-hook-form';

export interface ${NAME}Prop {

}

export default function ${NAME}({}: ${NAME}Prop) {
  return (
      <Wrap/>
  );
}

const Wrap = styled.div`
`;
