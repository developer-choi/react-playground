#set($ROOT_PATH = $NAME.replace('Api', '').toLowerCase())

import BaseApi from './BaseApi';

export default class ${NAME} extends BaseApi {
  constructor() {
    super('/${ROOT_PATH}');
  }
}
