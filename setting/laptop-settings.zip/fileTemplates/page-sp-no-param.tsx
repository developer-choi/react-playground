#set($COMPONENT_NAME = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1).replace('-', ''))

import React from 'react';
import Head from 'next/head';
import type {GetServerSideProps} from 'next';

interface PageProp {

}

export const getStaticProps: GetStaticProps<PageProp> = async ({}) => {

  return {
    props: {
    
    }
  };
};

export default function ${COMPONENT_NAME}Page({}: PageProp) {

  return (
    <>
      <Head>
        <title>${NAME}</title>
      </Head>
      <div>
        ${NAME} Page
      </div>
    </>
  );
}
