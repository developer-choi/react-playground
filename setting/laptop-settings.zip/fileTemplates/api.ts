import {Router} from 'express';

const ${NAME}Router = Router();
export default ${NAME}Router;

${NAME}Router.get('/some', function(req, res) {
  res.send('success');
});
