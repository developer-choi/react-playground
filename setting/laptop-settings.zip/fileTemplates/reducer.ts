#set($CAPITAL_FILENAME = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))

import {createSlice, PayloadAction, ThunkAction} from '@reduxjs/toolkit';
import type {RootState} from '@store/store';

export interface ${CAPITAL_FILENAME}State {
  someProp: {prop: string}
}

const initialState: ${CAPITAL_FILENAME}State = {
  someProp: {prop: 'dummy'}
};

const slice = createSlice({
  name: '${NAME}',
  initialState,
  reducers: {
    someActionCreator: state => {
      state.someProp.prop = 'dummy';
    },
    somePayloadActionCreator: (state, {payload}: PayloadAction<{prop: 'dummy'}>) => {
      state.someProp = payload;
    }
  }
});

export const { someActionCreator, somePayloadActionCreator } = slice.actions;
export default slice.reducer;

export function thunkSetProp(): ThunkAction<void, RootState, undefined, ReturnType<typeof somePayloadActionCreator>> {
  return async function (dispatch) {
    dispatch(somePayloadActionCreator({prop: 'dummy'}))
  };
}
