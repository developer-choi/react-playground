import React from 'react';
import type {GetServerSideProps} from 'next';

interface PageProp {
}

export default function Page({}: PageProp) {
  return (
    <>
    </>
  );
}

export const getServerSideProps: GetServerSideProps<PageProp> = async context => {
  return {
    props: {
    }
  };
};
