import React from 'react';
import type {GetServerSideProps} from 'next';

#set($dir = $DIR_PATH.replace('pages', ''))
#set($file = $NAME.replace('.tsx', ''))
// URL: http://localhost:3000${dir}/${file}
interface PageProp {
}

export default function Page({}: PageProp) {
  return (
    <>
    </>
  );
}

export const getServerSideProps: GetServerSideProps<PageProp> = async context => {
  return {
    props: {
    }
  };
};
