#set($COMPONENT_NAME = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1).replace('-', ''))

import React from 'react';
import Head from 'next/head';
import type {GetServerSideProps} from 'next';

type ParamType = {
  id?: string[];
};

interface PageProp {

}

export const getServerSideProps: GetServerSideProps<PageProp, ParamType> = async ({params}) => {

  const {id = []} = params as ParamType;
  return {
    props: {
      nickNames: id
    }
  };
};

export default function ${COMPONENT_NAME}Page({}: PageProp) {

  return (
    <>
      <Head>
        <title>${NAME}</title>
      </Head>
      <div>
        ${NAME} Page
      </div>
    </>
  );
}
