import React from 'react';
import styled from 'styled-components/native';
import {ViewProps} from 'react-native';

export interface ${NAME}Prop extends ViewProps {

}

export default function ${NAME}({...rest}: ${NAME}Prop) {

    return (
        <Wrap {...rest}>
        </Wrap>
    );
}

const Wrap = styled.View`
`;