import {axiosInstance} from './config';

export async function apiGetUrlPascalCase() {
    return (await axiosInstance.get(`/url-kebab-case`)).data as number;
}