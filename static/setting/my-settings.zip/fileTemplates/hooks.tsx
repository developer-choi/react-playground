import React from 'react';
import styled from 'styled-components';

export interface ${NAME}Prop {

}

export default function ${NAME}(props: ${NAME}Prop) {

    return (
        <${NAME}Style>
            This is ${NAME} Page 
        </${NAME}Style>
    );
}

const ${NAME}Style = styled.div`
`;