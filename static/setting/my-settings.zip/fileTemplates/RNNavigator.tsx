#set($REPLACE_NAME = $NAME.replace("Navigator", ""))

import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';

export type ${REPLACE_NAME}StackParamList = {
  ROUTE_NAME: ROUTE_PARAM_TYPE;
}

export default function $NAME() {

  const ${REPLACE_NAME}Stack = createStackNavigator<${REPLACE_NAME}StackParamList>();
  const ${REPLACE_NAME}Drawer = createDrawerNavigator();
  const ${REPLACE_NAME}Tabs = createBottomTabNavigator();

  return (
    <${REPLACE_NAME}Stack.Navigator screenOptions={{headerShown: false}}>
      <${REPLACE_NAME}Stack.Screen name="ROUTE_NAME" component={ComponentName}/>
    </${REPLACE_NAME}Stack.Navigator>
  );
}
