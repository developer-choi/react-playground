#set($capitalizedFilename = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))

import {createAction, handleActions} from "redux-actions";

//Actions
const SET_SOME_PROP = "${PROJECT_NAME}/$NAME/SET_SOME_PROP";

//Action Creators
export const setSomeProp = createAction<{prop: string}>(SET_SOME_PROP);

//state and reducer
export interface ${capitalizedFilename}State {
    someProp: {prop: string}
}

const initialState:${capitalizedFilename}State = {
    someProp: {prop: "dummy"}
};

export const reducer = handleActions<${capitalizedFilename}State, any>({

    [SET_SOME_PROP]: (state, action: ReturnType<typeof setSomeProp>) => ({
        ...state,
        someProp: action.payload
    }),

}, initialState);
