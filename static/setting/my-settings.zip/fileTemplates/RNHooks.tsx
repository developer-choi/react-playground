import React from 'react';
import styled from 'styled-components/native';

export interface ${NAME}Prop {

}

export default function ${NAME}({}: ${NAME}Prop) {

    return (
        <${NAME}Style>
        </${NAME}Style>
    );
}

const ${NAME}Style = styled.View`
`;