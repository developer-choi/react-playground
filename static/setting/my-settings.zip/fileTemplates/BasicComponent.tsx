import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

export interface ${NAME}Prop {

}

export default function $NAME({style, children, ...rest}: ${NAME}Prop) {

  return (
    <View style={[styles.container, style]} {...rest}>
        {children}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
  }
});
