import React from "react";
import "./${NAME}.scss";

export interface ${NAME}Prop {

}

export default function ${NAME}(props: ${NAME}Prop) {

    return (
        <div className="${NAME}-wrap">
        </div>
    );
}