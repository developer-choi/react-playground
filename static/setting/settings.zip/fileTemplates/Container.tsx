#set($NOT_CONTAINER_NAME = $NAME.replace("Container", ""))

import * as React from "react";
import {connect} from "react-redux";

export interface ${NAME}Prop {

}

function ${NAME}(props: ${NAME}Prop) {

    return <${NOT_CONTAINER_NAME} {...props}/>;
}

function mapState(rootState: RootState) {
    
    return {
        
    };
}

const mapDispatch = {
};

export default connect(mapState, mapDispatch)(${NAME});