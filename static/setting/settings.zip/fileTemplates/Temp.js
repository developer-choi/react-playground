import "./${NAME}.css";

export default function $NAME() {
    return `
        <div class="${NAME}-wrap"></div>
    `;
}
