import React from "react";
import {View, Text, StyleSheet} from "react-native";

export interface ${NAME}Prop {

}

export default function $NAME(props: ${NAME}Prop) {

  return (
    <View style={styles.container}>
        <Text>This is $NAME Page</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
  }
});
