import {RouteProps} from "react-router";

const ${NAME}: RouteProps[] = [
    {path: "/", component: App},
].map(route => ({...route, exact: true}));

export default ${NAME};
