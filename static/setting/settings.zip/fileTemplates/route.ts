import {RouteProps} from "react-router";

const routes: RouteProps[] = [
    {path: "/", component: App},
].map(route => ({...route, exact: true}));

export default routes;
