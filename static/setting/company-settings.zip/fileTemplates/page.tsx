import React from 'react';
import styled from 'styled-components';

export default function ${NAME}() {

  useSetDocumentTitle();

  return (
      <Wrap>
          This is ${NAME} Page 
      </Wrap>
  );
}

const Wrap = styled.div`
`;