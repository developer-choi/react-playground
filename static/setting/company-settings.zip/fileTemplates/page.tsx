import React from 'react';

export default function ${NAME}() {

  return (
      <div>
          ${NAME} Page 
      </div>
  );
}

export async function getStaticProps() {
  
}

export async function getStaticPaths() {

}

export async function getServerSideProps() {

}
