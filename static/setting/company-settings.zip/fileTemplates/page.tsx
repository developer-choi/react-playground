import React from 'react';
import styled from 'styled-components';

export default function ${NAME}() {

    return (
        <${NAME}Style>
            This is ${NAME} Page 
        </${NAME}Style>
    );
}

const ${NAME}Style = styled.div`
`;