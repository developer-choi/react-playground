import React from 'react';
import styled from 'styled-components';
import I18n from 'i18n-js';
import {useHistory, useLocation, useParams} from 'react-router-dom';

export default function ${NAME}() {

  useSetDocumentTitle(I18n.t('common1'));
  const {push} = useHistory();
  const {search, pathname} = useLocation();
  const {id} = useParams<{id: string}>();

  return (
      <Wrap>
          This is ${NAME} Page 
      </Wrap>
  );
}

const Wrap = styled.div`
`;