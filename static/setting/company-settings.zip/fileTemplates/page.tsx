import React from 'react';
import styled from 'styled-components';
import I18n from 'i18n-js';

export default function ${NAME}() {

  useSetDocumentTitle(I18n.t('common'));

  return (
      <Wrap>
          This is ${NAME} Page 
      </Wrap>
  );
}

const Wrap = styled.div`
`;