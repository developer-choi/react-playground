import React from 'react';
import styled from 'styled-components/native';
import {Text} from 'react-native';

export interface ${NAME}Prop {

}

export default function ${NAME}(props: ${NAME}Prop) {

    return (
        <${NAME}Style>
        </${NAME}Style>
    );
}

const ${NAME}Style = styled.View`
`;