import React from 'react';
import {Text, StyleSheet} from 'react-native';

export interface ${NAME}Prop {

}

export default function $NAME(props: ${NAME}Prop) {

  return (
    <BasicContainer>
        <Text>This is $NAME Page</Text>
    </BasicContainer>
  );
}

const styles = StyleSheet.create({
});
