import React, {ComponentProps} from 'react';
import styled from 'styled-components';

export interface ${NAME}Prop extends Omit<ComponentProps<'div'>, 'ref'> {

}

export default function ${NAME}({...rest}: ${NAME}Prop) {

    return (
        <Wrap {...rest}/>
    );
}

const Wrap = styled.div`
`;