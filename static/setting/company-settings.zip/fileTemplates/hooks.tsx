import React, {ComponentProps} from 'react';
import styled from 'styled-components';

export interface ${NAME}Prop extends Omit<ComponentProps<'div'>, 'ref'> {

}

export default function ${NAME}({style, ...rest}: ${NAME}Prop) {

    return (
        <${NAME}Style style={{...style}} {...rest}/>
    );
}

const ${NAME}Style = styled.div`
`;