import React, {DivProp} from 'react';
import styled from 'styled-components';

export interface ${NAME}Prop extends DivProp {

}

export default function ${NAME}({...rest}: ${NAME}Prop) {

    return (
        <Wrap {...rest}/>
    );
}

const Wrap = styled.div`
`;