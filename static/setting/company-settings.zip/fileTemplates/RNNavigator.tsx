#set($REPLACE_NAME = $NAME.replace("Navigator", ""))

import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';

export type ${REPLACE_NAME}StackParamList = {
  ComponentName: undefined
}

export type ${REPLACE_NAME}DrawerParamList = {
  ComponentName: undefined
}

export type ${REPLACE_NAME}TabsParamList = {
  ComponentName: undefined
}

export default function $NAME() {

  const ${REPLACE_NAME}Stack = createStackNavigator<${REPLACE_NAME}StackParamList>();
  const ${REPLACE_NAME}Drawer = createDrawerNavigator<${REPLACE_NAME}DrawerParamList>();
  const ${REPLACE_NAME}Tabs = createBottomTabNavigator<${REPLACE_NAME}TabsParamList>();

  return (
    <${REPLACE_NAME}Stack.Navigator screenOptions={{headerShown: false}}>
      <${REPLACE_NAME}Stack.Screen name="ComponentName" component={ComponentName}/>
    </${REPLACE_NAME}Stack.Navigator>
  );
}
