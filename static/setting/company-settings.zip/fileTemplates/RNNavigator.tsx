#set($REPLACE_NAME = $NAME.replace("Navigator", ""))

import React from "react";
import {createStackNavigator} from "@react-navigation/stack";
import {createDrawerNavigator} from "@react-navigation/drawer";
import {createBottomTabNavigator} from "@react-navigation/bottom-tabs";

export default function $NAME() {

  const ${REPLACE_NAME}Stack = createStackNavigator();
  const ${REPLACE_NAME}Drawer = createDrawerNavigator();
  const ${REPLACE_NAME}Tabs = createBottomTabNavigator();

  return (
    <${REPLACE_NAME}Stack.Navigator screenOptions={{headerShown: false}}>
      <${REPLACE_NAME}Stack.Screen name="ComponentName" component={ComponentName}/>
    </${REPLACE_NAME}Stack.Navigator>
  );
}
