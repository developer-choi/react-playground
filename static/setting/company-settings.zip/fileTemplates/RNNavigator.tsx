#set($REPLACE_NAME = $NAME.replace("Navigator", ""))

import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';

export type ${NAME}ParamList = {
  ROUTE_NAME: ROUTE_PARAM_TYPE;
}

export default function $NAME() {

  const ${REPLACE_NAME}Stack = createStackNavigator<${REPLACE_NAME}NavigatorParamList>();
  const ${REPLACE_NAME}Drawer = createDrawerNavigator<${REPLACE_NAME}NavigatorParamList>();
  const ${REPLACE_NAME}Tabs = createBottomTabNavigator<${REPLACE_NAME}NavigatorParamList>();

  return (
    <${REPLACE_NAME}Stack.Navigator screenOptions={{headerShown: false}}>
      <${REPLACE_NAME}Stack.Screen name="ROUTE_NAME" component={ComponentName}/>
    </${REPLACE_NAME}Stack.Navigator>
  );
}
