import React, {ComponentProps} from 'react';
import styled from 'styled-components';

export default function ${NAME}(props: Omit<ComponentProps<'div'>, 'ref'>) {

    return (
        <Wrap {...props}>
        </Wrap>
    );
}

const Wrap = styled.div`
`;