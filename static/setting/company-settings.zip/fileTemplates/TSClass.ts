export default class ${NAME} {

}