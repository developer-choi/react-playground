import React, {SvgProp} from 'react';

export default function ${NAME}(props: SvgProp) {

  return (
  );
}
