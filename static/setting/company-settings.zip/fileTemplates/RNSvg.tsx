import React from 'react';
import Svg, { G, Path, SvgProps } from 'react-native-svg';

export default function ${NAME}(props: SvgProps) {

  return (
    <Svg>
    </Svg>
  );
}
