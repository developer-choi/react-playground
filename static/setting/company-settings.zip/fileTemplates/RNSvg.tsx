import React from 'react';
import Svg, {G, Path, SvgProps} from 'react-native-svg';

export default function ${NAME}({color = 'white', ...rest}: SvgProps) {

  return (
    <Svg {...rest}>
    </Svg>
  );
}
