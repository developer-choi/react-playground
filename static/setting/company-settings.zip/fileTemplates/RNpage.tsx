import React from 'react';
import {Text} from 'react-native';

export default function ${NAME}() {

    return (
        <BasicContainer>
          <Text>This is ${NAME} Page</Text>
        </BasicContainer>
    );
}