import React from 'react';
import {Text, View} from 'react-native';

export default function ${NAME}() {

    return (
        <View>
          <Text>This is ${NAME} Page</Text>
        </View>
    );
}