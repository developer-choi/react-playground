import {axiosInstance} from './config';

export async function apiGetUrlPascalCase() {
  const res = await axiosInstance.get<ResponseType>('url-pascal-case');
  console.log('response-apiGetUrlPascalCase', res);
  return res;
}