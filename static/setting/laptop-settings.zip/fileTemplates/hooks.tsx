import React, {ComponentProps} from 'react';
import styled from 'styled-components';

export interface ${NAME}Prop extends Omit<ComponentProps<'div'>, 'ref'> {

}

export default function ${NAME}(props: ${NAME}Prop) {

    return (
        <${NAME}Style {...props}/>
    );
}

const ${NAME}Style = styled.div`
`;