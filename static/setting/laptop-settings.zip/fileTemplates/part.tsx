import React, {DivProp} from 'react';
import styled from 'styled-components';
import {useDispatch, useSelector, shallowEqual} from 'react-redux';

export default function ${NAME}() {

    return (
        <Wrap>
        </Wrap>
    );
}

const Wrap = styled.div`
`;