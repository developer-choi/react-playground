import React, {ComponentProps} from 'react';
import styled from 'styled-components';

export default function ${NAME}() {

    return (
        <Wrap>
        </Wrap>
    );
}

const Wrap = styled.div`
`;