#set($REPLACE_NAME = $NAME.replace("Navigator", ""))

import React from 'react';
import {
  createMaterialTopTabNavigator,
  MaterialTopTabBarOptions,
  MaterialTopTabNavigationOptions
} from '@react-navigation/material-top-tabs';
import {DefaultNavigatorOptions} from '@react-navigation/native';

export type ${NAME}ParamList = {
  ROUTE_NAME: undefined;
}

export default function $NAME() {

  const ${REPLACE_NAME}TopTab = createMaterialTopTabNavigator<${REPLACE_NAME}NavigatorParamList>();

  return (
    <${REPLACE_NAME}TopTab.Navigator lazy tabBarOptions={tabBarOptions} screenOptions={screenOptions}>
      <${REPLACE_NAME}TopTab.Screen name="ROUTE_NAME" component={ComponentName}/>
    </${REPLACE_NAME}TopTab.Navigator>
  );
}

const screenNameToTitle: Record<keyof ${NAME}ParamList, string> = {
  ROUTE_NAME: 'TITLE',
};

const screenOptions: DefaultNavigatorOptions<MaterialTopTabNavigationOptions, ${NAME}ParamList>['screenOptions'] = ({route}) => {
  return {
    title: screenNameToTitle[route.name]
  };
};

const tabBarOptions: MaterialTopTabBarOptions = {
};
