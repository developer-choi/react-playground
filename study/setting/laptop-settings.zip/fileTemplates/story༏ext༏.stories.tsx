export default {
  component: $NAME,
  title: 'dir/$NAME'
};

const Template = (props: ${NAME}Prop) => (
    <$NAME {...props}/>
);

export const Default: Story<${NAME}Prop> = Template.bind({});
Default.args = {
  children: 'Hello World'
};
