import React from 'react';
import styled from 'styled-components';

export interface ${NAME}Prop {

}

export default function ${NAME}({}: ${NAME}Prop) {

  return (
      <Wrap/>
  );
}

const Wrap = styled.div`
`;
