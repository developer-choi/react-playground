#set($COMPONENT_NAME = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1).replace('-', ''))

import React from 'react';
import Head from 'next/head';
import {GetStaticPaths, GetStaticProps} from 'next';

type ParamType = {
  id: string;
};

interface PageProp {

}

export const getStaticPaths: GetStaticPaths<ParamType> = async () => {

  return {
    paths: [
      {params: {id: ALLOW_PARAMS[0]}},
      {params: {id: ALLOW_PARAMS[1]}},
      {params: {id: ALLOW_PARAMS[2]}}
    ],
    fallback: false
  };
};

export const getStaticProps: GetStaticProps<PageProp, ParamType> = async ({params}) => {

  const {id} = params as ParamType;
  return {
    props: {
    
    }
  };
};

export default function ${COMPONENT_NAME}Page({}: PageProp) {
  return (
    <>
      <Head>
        <title>${NAME}</title>
      </Head>
      <div>
        ${NAME} Page
      </div>
    </>
  );
}
