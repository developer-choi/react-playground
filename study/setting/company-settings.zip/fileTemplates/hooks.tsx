import React from 'react';
import styled from 'styled-components';

export interface ${NAME}Props {

}

export const ${NAME} = ({}: ${NAME}Props) => {

  return (
      <Wrap/>
  );
}

export default ${NAME};