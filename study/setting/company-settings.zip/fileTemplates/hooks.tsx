import React from 'react';
import styled from 'styled-components';

export interface ${NAME}Prop {

}

export const ${NAME} = ({}: ${NAME}Prop) => {

  return (
      <Wrap/>
  );
}

export default ${NAME};