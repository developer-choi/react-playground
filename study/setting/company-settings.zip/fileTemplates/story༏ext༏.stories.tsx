import { Story } from '@storybook/react';

export interface ${NAME}Props {

}

export default {
  component: $NAME,
  title: 'Molecules/$NAME'
};

const Template: Story<${NAME}Props> = args => (
    <$NAME {...args}/>
);

export const Default = Template.bind({});
Default.args = {
    
};
