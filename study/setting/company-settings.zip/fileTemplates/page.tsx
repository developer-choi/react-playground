import React from 'react';
import Head from 'next/head';

export default function ${NAME}() {

  return (
    <>
      <Head>
        <title>${NAME}</title>
      </Head>
      <div>
        ${NAME} Page
      </div>
    </>
  );
}

export async function getStaticProps() {
  
}

export async function getStaticPaths() {

}

export async function getServerSideProps() {

}
