#set($COMPONENT_NAME = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1).replace('-', ''))

import React from 'react';
import Head from 'next/head';

const ${COMPONENT_NAME}Page = () => {

  return (
    <>
      <Head>
        <title>${NAME}</title>
      </Head>
      <div>
        ${NAME} Page
      </div>
    </>
  );
};

export default ${COMPONENT_NAME}Page;
