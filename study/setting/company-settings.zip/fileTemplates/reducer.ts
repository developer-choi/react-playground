#set($CAPITAL_FILENAME = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))

import {createAction, handleActions} from 'redux-actions';

const SET_SOME_PROP = '${PROJECT_NAME}/$NAME/SET_SOME_PROP';

export const setSomePropActionCreator = createAction<{prop: string}>(SET_SOME_PROP);

export function thunkSetProp(): ThunkAction<void, RootState, undefined, ReturnType<typeof setSomePropActionCreator>> {
  return async function (dispatch) {
    dispatch(setSomePropActionCreator({prop: 'dummy'}))
  };
}

export interface ${CAPITAL_FILENAME}State {
    someProp: {prop: string}
}

const initialState:${CAPITAL_FILENAME}State = {
    someProp: {prop: 'dummy'}
};

export const $NAME = handleActions<${CAPITAL_FILENAME}State, any>({

    [SET_SOME_PROP]: (state, action: ReturnType<typeof setSomePropActionCreator>) => ({
        someProp: action.payload
    }),

}, initialState);
